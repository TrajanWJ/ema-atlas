# 06 — Blueprint boundaries

Blueprint is the first (and initially only) vApp. Its data splits across
two planes and the boundary between them is load-bearing.

## The split

| Concern                         | Lives in          | Why                                                           |
| ------------------------------- | ----------------- | ------------------------------------------------------------- |
| Project has a blueprint         | canonical truth   | project-level structural fact                                 |
| List of documents in blueprint  | canonical truth   | access control, linking, replication                          |
| Section tree (headings)         | canonical truth   | structural ops should replay cleanly                          |
| Section ordering                | canonical truth   | deterministic replay                                          |
| Prose body of a section         | Yjs (per-doc)     | real-time collab, offline convergence                         |
| Inline cursors / presence       | Yjs awareness     | ephemeral                                                     |
| Comments on a section           | canonical truth   | need explicit promotion to proposal, audit trail              |
| Section → proposal promotion    | canonical truth   | cross-system event                                            |
| Attachments linked to a section | canonical truth   | pointer lives in `ema_attachments`, link is canonical         |

## Yjs shape

One Y.Doc per `blueprint_document`. Not one Y.Doc per project — per
document. This keeps:

- auth boundary per-document;
- load cost per-document;
- replication shape simple (one doc ↔ one websocket channel).

Hocuspocus-style `onAuthenticate` at websocket connect time gates access
per-doc. Within a doc, Yjs fragments carry prose per section.

## Structural events (canonical-side)

In `packages/contracts/events/blueprint.md`:

- `blueprint.document.created` / `.renamed` / `.archived`
- `blueprint.section.added` / `.renamed` / `.moved` / `.removed`
- `blueprint.section.promoted_to_proposal`
- `blueprint.comment.added` / `.resolved`
- `blueprint.attachment.linked` / `.unlinked` (mirrors
  `attachment.linked` with the blueprint context populated)

## What this wave ships

- Canonical event stubs in the catalog.
- `blueprint.md` vApp doc.
- A placeholder vApp page in `apps/web/src/vapps/blueprint/` that renders
  a fake section tree from a projection and demonstrates the **Attach…**
  button handing off to git-ema's attach dialog.
- **No Yjs wiring yet.** Hocuspocus server is a later wave.
