//// Localhost WebSocket IPC server.
////
//// Accepts connections from Tauri desktop and browser surfaces on
//// `ws://127.0.0.1:<ema-port>`. Routes `command` messages to the right
//// bounded context's writer, streams `event` messages from the bus to
//// subscribed clients, and sends `projection` snapshots on subscribe.
////
//// Wire protocol: `packages/contracts/ipc/shell-protocol.md` v0.
////
//// Wave 1: skeleton. Wire types present so the surface ipc-client can
//// compile against them conceptually; real WS handling lands next wave.

pub const default_port: Int = 49_555

pub type HelloSurface {
  SurfaceWeb
  SurfaceDesktop
}

pub type Hello {
  Hello(
    v: Int,
    id: String,
    surface: HelloSurface,
    device_id: Option(String),
  )
}

pub type Option(a) {
  None
  Some(a)
}

pub type Command {
  Command(v: Int, id: String, op: String, args_json: String)
}

pub type CommandResult {
  CommandOk(in_reply_to: String, event_ids: List(String))
  CommandErr(in_reply_to: String, class: String, message: String)
}

pub type Event {
  Event(v: Int, channel: String, event_json: String)
}

pub type Projection {
  Projection(v: Int, name: String, data_json: String)
}

pub type Subscribe {
  Subscribe(v: Int, id: String, channel: String)
}
