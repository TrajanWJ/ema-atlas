//// In-process event bus.
////
//// Writer actors append events through the bus so that:
////   (1) append order is linear per daemon instance,
////   (2) projections and the IPC fan-out subscribe in one place,
////   (3) replication reads from the bus tail.
////
//// See `packages/contracts/events/` for the canonical event shape.

import gleam/erlang/process.{type Subject}

pub type Envelope {
  Envelope(
    event_id: String,
    kind: String,
    ts: String,
    actor: String,
    org_id: String,
    space_id: Option(String),
    project_id: Option(String),
    dispatch_id: Option(String),
    execution_id: Option(String),
    payload_json: String,
  )
}

pub type Option(a) {
  None
  Some(a)
}

pub type Msg {
  /// Append an event. Returns the assigned event_id on success.
  Append(env: Envelope, reply: Subject(Result(String, AppendError)))

  /// Subscribe a caller to events whose `kind` starts with `prefix`.
  /// Use empty string to subscribe to all.
  Subscribe(prefix: String, target: Subject(Envelope))

  /// Unsubscribe a previously registered target.
  Unsubscribe(target: Subject(Envelope))
}

pub type AppendError {
  InvalidKind(kind: String)
  NotInCatalog(kind: String)
  PersistenceFailed(reason: String)
}

pub type State {
  State(
    next_txid: Int,
    subscribers: List(#(String, Subject(Envelope))),
  )
}

pub fn empty_state() -> State {
  State(next_txid: 0, subscribers: [])
}
