/**
 * Surface → daemon WebSocket client.
 *
 * Protocol: packages/contracts/ipc/shell-protocol.md (v0).
 *
 * This is the single place that knows how to speak EMA's IPC. Surfaces
 * use the higher-level hooks in `@ema/web` (useProjection, useCommand)
 * rather than calling methods directly.
 */

export type SurfaceKind = "web" | "desktop";

export type IpcClientOptions = {
  url: string;
  surface: SurfaceKind;
};

export type CommandResult =
  | { ok: true; event_ids: string[]; [key: string]: unknown }
  | { ok: false; error: { class: string; message: string } };

export type ProjectionListener<T> = (data: T | null) => void;

export interface IpcClient {
  connect(): void;
  disconnect(): void;
  sendCommand(op: string, args: Record<string, unknown>): Promise<CommandResult>;
  subscribeProjection<T = unknown>(
    name: string,
    listener: ProjectionListener<T>,
  ): () => void;
}

/**
 * Create an IPC client. Not connected until `.connect()` is called.
 *
 * Wave 1: the implementation is a thin stub. Commands reject with
 * `{ class: "not_implemented" }`. `subscribeProjection` stores listeners
 * and invokes them with `null` once to indicate "offline". This lets the
 * surface render against the real hook API today.
 *
 * Wave 2 fills in real WS framing.
 */
export function createIpcClient(options: IpcClientOptions): IpcClient {
  const listeners = new Map<string, Set<ProjectionListener<any>>>();
  let connected = false;

  return {
    connect() {
      connected = true;
      // TODO(ema-0.0.5 wave 2): open websocket, handshake.
      // For now: notify all subscribers with null (so UI renders an
      // offline state).
      for (const [, set] of listeners) {
        for (const l of set) l(null);
      }
    },
    disconnect() {
      connected = false;
      // TODO(ema-0.0.5 wave 2): close websocket.
    },
    async sendCommand(op: string, _args: Record<string, unknown>): Promise<CommandResult> {
      if (!connected) {
        return { ok: false, error: { class: "internal", message: "not connected" } };
      }
      // TODO(ema-0.0.5 wave 2): frame command, await reply.
      return {
        ok: false,
        error: {
          class: "not_implemented",
          message: `ipc-client stub: ${op} not wired yet`,
        },
      };
    },
    subscribeProjection<T>(name: string, listener: ProjectionListener<T>) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      const set = listeners.get(name)!;
      set.add(listener as ProjectionListener<any>);
      // Give the listener an initial null so UI can render offline
      // state without waiting.
      listener(null);
      return () => {
        set.delete(listener as ProjectionListener<any>);
        if (set.size === 0) listeners.delete(name);
      };
    },
  };
}

// Re-export for convenience when imported as @ema/surface-core/ipc-client
export { createIpcClient as default };

// Suppress unused-param warning in stub.
void ({ _surfaceKind: null as SurfaceKind | null });
