# Event catalog

See `catalog.v0.md` for the full, flat list of event kinds across every
family.

## Adding a kind

1. Add the kind to the family file (`<family>.md`) with its payload
   shape and consumers.
2. Add the kind to `catalog.v0.md` (single source of truth for the
   contract check).
3. Reference the kind in daemon + surface code.

The pre-commit contract check reads `catalog.v0.md` and fails if any
kind appears in code that is not listed here.

## Envelope (shared by every event)

```
event {
  event_id:      event:<ulid>
  kind:          <family>.<verb>[.<subverb>]
  ts:            ISO-8601 UTC
  actor:         user:<ulid> | device:<ulid> | system:<component>
  org_id:        org:<ulid>
  space_id?:     space:<ulid>
  project_id?:   project:<ulid>
  dispatch_id?:  dispatch:<ulid>     // Hermes seam
  execution_id?: execution:<ulid>    // Hermes seam
  payload:       <family-specific>
}
```

## Families

| Family        | File                | Owner context         |
| ------------- | ------------------- | --------------------- |
| org           | `org.md`            | ema_orgs              |
| space         | `space.md`          | ema_spaces            |
| project       | `project.md`        | ema_projects          |
| membership    | `membership.md`     | ema_memberships       |
| invite        | `invite.md`         | ema_invites           |
| device        | `device.md`         | ema_identity          |
| peer          | `peer.md`           | ema_replication       |
| lease         | `lease.md`          | ema_replication       |
| replication   | `replication.md`    | ema_replication       |
| lane          | `lane.md`           | (future) ema_coord    |
| handoff       | `handoff.md`        | (future) ema_coord    |
| proposal      | `proposal.md`       | (future) ema_coord    |
| incident      | `incident.md`       | (future) ema_coord    |
| dispatch      | `dispatch.md`       | ema_control seam      |
| execution     | `execution.md`      | ema_exec seam         |
| tool          | `tool.md`           | ema_exec seam         |
| blueprint     | `blueprint.md`      | ema_blueprint         |
| attachment    | `attachment.md`     | ema_attachments       |
| connector     | `connector.md`      | ema_attachments       |
