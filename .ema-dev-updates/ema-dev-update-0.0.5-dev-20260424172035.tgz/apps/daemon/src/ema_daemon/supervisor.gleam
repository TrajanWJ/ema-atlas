//// Top-level supervision tree.
////
//// Shape (see docs/architecture/02-daemon-supervision.md):
////
////   ema_daemon_sup (one_for_one)
////   ├── bus              (singleton)
////   ├── registry         (Singularity-style)
////   ├── shell_ipc_sup    (localhost WS acceptor + workers)
////   └── contexts_sup     (rest_for_one)
////       ├── identity_sup
////       ├── orgs_sup
////       ├── spaces_sup
////       ├── projects_sup
////       ├── memberships_sup
////       ├── invites_sup
////       ├── blueprint_sup
////       ├── attachments_sup   (git-ema backend)
////       └── replication_sup
////
//// This file is the skeleton — children are stubs until their bounded
//// contexts are fleshed out.

pub type SupervisorError {
  ChildFailedToStart(child: String)
}

pub type StartedTree {
  StartedTree
}

/// Start the full supervision tree.
///
/// For wave 1 this just returns Ok. The real OTP wiring lands as each
/// bounded context is implemented.
pub fn start() -> Result(StartedTree, SupervisorError) {
  // TODO(ema-0.0.5): wire actual gleam_otp supervisors here.
  //
  //   bus.start()
  //   registry.start()
  //   shell_ipc.start()
  //   contexts_sup.start()
  //
  // Each must register under a well-known name so cross-context code
  // can look it up via `registry`.
  Ok(StartedTree)
}

/// Inspect current children for dev tooling.
pub fn children() -> List(String) {
  [
    "bus",
    "registry",
    "shell_ipc_sup",
    "contexts_sup/identity_sup",
    "contexts_sup/orgs_sup",
    "contexts_sup/spaces_sup",
    "contexts_sup/projects_sup",
    "contexts_sup/memberships_sup",
    "contexts_sup/invites_sup",
    "contexts_sup/blueprint_sup",
    "contexts_sup/attachments_sup",
    "contexts_sup/replication_sup",
  ]
}
