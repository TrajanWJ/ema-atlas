# space

Owner: `ema_spaces`.

## Kinds

### `space.created`
```
payload {
  space_id: space:<ulid>
  org_id:   org:<ulid>
  name:     string
  created_by: user:<ulid>
}
```

### `space.renamed`
```
payload { space_id, from, to }
```

### `space.settings_updated`
```
payload { space_id, changes: { <key>: <value> } }
```

### `space.archived`
```
payload { space_id, reason? }
```

### `space.member_added`
```
payload {
  space_id: space:<ulid>
  user_id:  user:<ulid>
  role:     "owner" | "admin" | "member" | "guest"
}
```

### `space.member_removed`
```
payload { space_id, user_id }
```
