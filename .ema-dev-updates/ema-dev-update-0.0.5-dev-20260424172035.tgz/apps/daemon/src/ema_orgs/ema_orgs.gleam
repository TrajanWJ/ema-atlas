//// ema_orgs — organizations (including personal orgs).
////
//// Wave 1: stub. Handles commands `org.create`, etc.

pub type Placeholder {
  Placeholder
}
