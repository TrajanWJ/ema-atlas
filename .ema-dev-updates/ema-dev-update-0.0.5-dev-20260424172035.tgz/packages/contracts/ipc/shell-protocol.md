# Shell protocol — daemon ↔ surface (v0)

Transport: WebSocket on `ws://127.0.0.1:<ema-port>`.

Framing: one JSON object per WS text message.

## Message shape

Every message has:

```
{
  "v": 0,                 // protocol version
  "id": "msg-<ulid>",     // unique per message
  "type": "command" | "command_result" | "event" | "subscribe" | "unsubscribe" | "projection" | "hello" | "bye",
  ...
}
```

## Handshake

Client → server:
```
{ "v": 0, "id": "msg-...", "type": "hello",
  "surface": "web" | "desktop",
  "device_id": "device:<ulid>" | null   // null until paired
}
```

Server → client:
```
{ "v": 0, "id": "msg-...", "type": "hello",
  "daemon_version": "0.0.5-dev",
  "accepted_device_id": "device:<ulid>" | null,
  "note": string | null
}
```

Auth (device key ceremony) is a later wave; for 0.0.5-wave-1 the daemon
accepts any hello and assigns a dev device id on the fly.

## Commands (surface → daemon)

```
{ "v": 0, "id": "msg-...", "type": "command",
  "op": "<op-name>",
  "args": { ... }
}
```

Server responds with one message:

```
{ "v": 0, "type": "command_result",
  "in_reply_to": "msg-...",
  "ok": true,
  "events": [ "event:<ulid>", ... ]      // ids of events appended
}
```
or
```
{ "v": 0, "type": "command_result",
  "in_reply_to": "msg-...",
  "ok": false,
  "error": { "class": "...", "message": "..." }
}
```

### v0 commands

| op                            | args                                                         |
| ----------------------------- | ------------------------------------------------------------ |
| `org.create`                  | `{ name }`                                                   |
| `space.create`                | `{ org_id, name }`                                           |
| `project.create`              | `{ space_id, name }`                                         |
| `connector.connect`           | `{ provider: "google_drive" \| "github" }`                   |
| `connector.disconnect`        | `{ connector_id }`                                           |
| `connector.import_resource`   | `{ connector_id, picker_item_id }`                           |
| `attachment.rename`           | `{ attachment_id, name }`                                    |
| `attachment.delete`           | `{ attachment_id }`                                          |
| `attachment.link`             | `{ attachment_id, object_kind, object_id }`                  |
| `attachment.unlink`           | `{ attachment_id, object_kind, object_id }`                  |
| `connector.list_picker_items` | `{ connector_id }` → `command_result.picker_items`           |

The last one is a **query** that returns inline data on `command_result`
rather than emitting events (read path, not write path).

## Events (daemon → surface)

Pushed after successful appends to clients subscribed to the relevant
channel.

```
{ "v": 0, "type": "event",
  "channel": "<channel-name>",
  "event": { ...full canonical event envelope... }
}
```

## Subscribe / unsubscribe

```
{ "v": 0, "id": "msg-...", "type": "subscribe",
  "channel": "<channel-name>" }
```

### v0 channels

| Channel                              | What streams                                              |
| ------------------------------------ | --------------------------------------------------------- |
| `user.<user_id>.orgs`                | org + membership events visible to this user              |
| `org.<org_id>.spaces`                | space events within this org                              |
| `space.<space_id>.projects`          | project events within this space                          |
| `project.<project_id>.all`           | every event scoped to this project                        |
| `project.<project_id>.attachments`   | attachment + link events for this project                 |
| `user.<user_id>.connectors`          | connector events for this user                            |

## Projections (daemon → surface)

Initial snapshots sent on subscribe, and periodic replacements when the
daemon recomputes:

```
{ "v": 0, "type": "projection",
  "name": "<projection-name>",
  "data": { ... }
}
```

### v0 projections

| Name                                    | Shape                                                         |
| --------------------------------------- | ------------------------------------------------------------- |
| `topbar`                                | `{ user, orgs[], current_org?, spaces[], current_space?, projects[], current_project? }` |
| `git_ema.project_attachments`           | `{ attachments[] }`                                           |
| `git_ema.user_connectors`               | `{ connectors[] }`                                            |
| `blueprint.sections`                    | `{ documents[] with section_tree[] }`                         |

## Error classes

- `unknown_op`
- `invalid_args`
- `not_found`
- `forbidden`
- `conflict`
- `internal`

## Versioning

- `v: 0` is the only accepted version until a breaking change.
- New commands / channels / projections can be added under `v: 0`
  (additive).
- Breaking changes bump to `v: 1` and this file is re-published as
  `shell-protocol.v1.md`.
