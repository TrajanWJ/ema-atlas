# EMA-0.0.5--4-24

This is the actual implementation home for EMA `0.0.5`.

If you are writing code for EMA rather than reading history, this is where that
work should happen.

## Product direction locked for this repo

- daemon-first
- native-first
- `Organization -> Space -> Project`
- first deep project-thinking vApp: `Blueprint`
- first source/attachment vApp: `git-ema`
- first milestone: a vanilla workspace ready for workflow later
- full organization, space, project, settings, and invite surfaces from day one
- shell topbar includes:
  - project selector
  - space selector

## Intended repo shape

```text
EMA-0.0.5--4-24/
├── apps/
│   ├── daemon/
│   ├── desktop/
│   └── web/
├── packages/
│   ├── contracts/
│   ├── surface-core/
│   └── design-system/
├── docs/
├── scripts/
└── tooling/
```

## Role of each app

- `apps/daemon/`
  - EMA authority, truth ownership, sync, identity, control plane
- `apps/desktop/`
  - native EMA shell
- `apps/web/`
  - browser-hosted shell for parity, access, and development

## What should be built first

1. daemon boundaries and data contracts
2. shell structure with org/space/project selectors
3. vanilla workspace shape
4. Blueprint as the first deep vApp
5. git-ema as the first source/attachment vApp
6. org/space/project/settings/invite surfaces

## What should not happen here

- donor code copied in blindly
- archive docs mixed into runtime source folders
- implementation starting inside old imported roots instead of this repo

## Supporting docs

- [docs/WORKSPACE-ENTRYPOINT.md](./docs/WORKSPACE-ENTRYPOINT.md)
- [docs/dev/p2p-dev-updates.md](./docs/dev/p2p-dev-updates.md)
- [docs/architecture/08-vanilla-workspace.md](./docs/architecture/08-vanilla-workspace.md)
- [../../doctrine/planning/EMA-0.0.5-LANGUAGE-LOCK.md](../../doctrine/planning/EMA-0.0.5-LANGUAGE-LOCK.md)
- [../../doctrine/planning/EMA-0.0.5-PASSOVER-AND-PREP.md](../../doctrine/planning/EMA-0.0.5-PASSOVER-AND-PREP.md)
- [../../data-model/EMA-DATA-TREATMENT-AND-SOURCE-OF-TRUTH.md](../../data-model/EMA-DATA-TREATMENT-AND-SOURCE-OF-TRUTH.md)
