# device

Owner: `ema_identity`.

## Kinds

### `device.registered`
```
payload {
  device_id:   device:<ulid>
  user_id:     user:<ulid>
  name:        string             // human label ("Tawj MBP")
  pubkey:      hex                // Ed25519 public key
  bootstrap:   "genesis" | "paired"
}
```

### `device.renamed`
```
payload { device_id, from, to }
```

### `device.revoked`
```
payload {
  device_id: device:<ulid>
  revoked_by: user:<ulid> | device:<ulid>
  reason?: string
}
```

### `device.key_rotated`
```
payload {
  device_id: device:<ulid>
  old_pubkey: hex
  new_pubkey: hex
}
```
