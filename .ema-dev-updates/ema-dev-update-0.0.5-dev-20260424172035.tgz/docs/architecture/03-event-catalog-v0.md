# 03 — Event catalog v0

The canonical event catalog lives in
[`../../packages/contracts/events/`](../../packages/contracts/events/).

This file is a pointer and policy note, not the list itself.

## Why a versioned catalog

Event kinds are a system contract. They cross:

- daemon bounded contexts (via the in-process bus);
- daemon → surface (via IPC fan-out);
- daemon → daemon (via replication);
- audit + replay (via the canonical log).

Ad-hoc kinds break all four boundaries. Every kind in use MUST be present
in `packages/contracts/events/catalog.v0.md`. A pre-commit contract-check
script under `tooling/` enforces this.

## Families (v0)

`org`, `space`, `project`, `membership`, `invite`, `device`, `peer`,
`lease`, `replication`, `lane`, `handoff`, `proposal`, `incident`,
`dispatch`, `execution`, `tool`, `blueprint`, `attachment`, `connector`.

See `catalog.v0.md` for the full kind list; each family has its own
file with kinds, payload shapes, and intended consumers.

## Common envelope

Every event regardless of family carries:

```
{
  event_id:    event:<ulid>
  kind:        <family>.<verb>[.<subverb>]
  ts:          ISO-8601 UTC
  actor:       user:<ulid> | device:<ulid> | system:<component>
  org_id:      org:<ulid>
  space_id?:   space:<ulid>
  project_id?: project:<ulid>
  dispatch_id?: dispatch:<ulid>      (Hermes seam)
  execution_id?: execution:<ulid>    (Hermes seam)
  payload:     <family-specific>
}
```

## Versioning

- Additive changes (new kinds, new optional payload fields) do not require
  a catalog version bump.
- Removing a kind, renaming a kind, or changing a required payload field
  requires a new `catalog.vN.md` and a migration note.
- The old catalog files are preserved — never edited in place after v0
  ships.
