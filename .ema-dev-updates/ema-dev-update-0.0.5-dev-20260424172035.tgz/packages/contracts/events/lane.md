# lane

Owner: (future) `ema_coord`.

Lanes are first-class coordination objects: a named workstream inside
a project that groups items (issues, tasks, proposals-in-flight). This
wave ships the event family stubs only; implementation is a later wave.

## Kinds

### `lane.opened`
```
payload {
  lane_id:    lane:<ulid>
  project_id: project:<ulid>
  name:       string
  opened_by:  user:<ulid>
}
```

### `lane.closed`
```
payload { lane_id, reason? }
```

### `lane.item_added`
```
payload {
  lane_id: lane:<ulid>
  item: { kind: "proposal" | "incident" | "blueprint_section" | "attachment", id: string }
  position: int
}
```

### `lane.item_moved`
```
payload { lane_id, item_id, from_position: int, to_position: int }
```
