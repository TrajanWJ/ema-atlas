import { useProjection } from "../lib/ipc";
import { OrgSelector } from "./org-selector";
import { SpaceSelector } from "./space-selector";
import { ProjectSelector } from "./project-selector";
import { ConnectorsIndicator } from "./connectors-indicator";

/**
 * Topbar — always renders three selectors (org / space / project),
 * plus the connectors indicator (lit when any connector is connected).
 *
 * Selectors are projection-driven. When the daemon is unreachable the
 * topbar shows a small "daemon unreachable" badge and selectors
 * disable.
 */
export function Topbar() {
  const topbar = useProjection("topbar");

  const offline = topbar == null;

  return (
    <header className="ema-topbar" data-offline={offline ? "true" : "false"}>
      <div className="ema-topbar__brand">EMA</div>

      <div className="ema-topbar__selectors">
        <OrgSelector />
        <span className="ema-topbar__sep">/</span>
        <SpaceSelector />
        <span className="ema-topbar__sep">/</span>
        <ProjectSelector />
      </div>

      <div className="ema-topbar__right">
        <ConnectorsIndicator />
        {offline && <span className="ema-topbar__badge">daemon unreachable</span>}
      </div>
    </header>
  );
}
