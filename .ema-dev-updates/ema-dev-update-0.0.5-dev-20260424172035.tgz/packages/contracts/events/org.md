# org

Owner: `ema_orgs`.

## Kinds

### `org.created`
```
payload {
  org_id: org:<ulid>
  name: string
  personal: bool              // true for the auto-created personal org
  owner_user_id: user:<ulid>
}
```

### `org.renamed`
```
payload {
  org_id: org:<ulid>
  from: string
  to: string
}
```

### `org.settings_updated`
```
payload {
  org_id: org:<ulid>
  changes: { <key>: <value> }
}
```

### `org.archived`
```
payload {
  org_id: org:<ulid>
  reason?: string
}
```
