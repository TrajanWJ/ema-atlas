/**
 * Typed projection shapes (v0).
 *
 * These mirror the projections daemon emits over IPC. Surfaces import
 * these types instead of redefining them.
 */

import type { SelectorState } from "../selectors";

export type TopbarProjection = SelectorState & {
  user: { id: string; display_name: string };
};

export type GitEmaUserConnectorsProjection = {
  connectors: Array<{
    id: string;
    provider: "google_drive" | "github";
    status: "connected" | "disconnected";
    display_label: string;
    connected_at: string | null;
  }>;
};

export type GitEmaAttachmentsProjection = {
  attachments: Array<{
    id: string;
    kind: string;
    source: string;
    display_name: string;
    mime?: string;
    size_bytes?: number;
  }>;
};

export type BlueprintSectionsProjection = {
  documents: Array<{
    id: string;
    title: string;
    sections: Array<BlueprintSectionNode>;
  }>;
};

export type BlueprintSectionNode = {
  id: string;
  title: string;
  children?: BlueprintSectionNode[];
};

export const PROJECTION_NAMES = {
  topbar: "topbar",
  gitEmaUserConnectors: "git_ema.user_connectors",
  gitEmaUserAttachments: "git_ema.user_attachments",
  gitEmaProjectAttachments: "git_ema.project_attachments",
  blueprintSections: "blueprint.sections",
} as const;
