# peer

Owner: `ema_replication`.

## Kinds

### `peer.seen`
```
payload {
  peer_device: device:<ulid>
  last_txid:   int
  last_checksum: hex
  seen_at:     ISO-8601 UTC
}
```

### `peer.unreachable`
```
payload { peer_device, last_seen_at }
```
