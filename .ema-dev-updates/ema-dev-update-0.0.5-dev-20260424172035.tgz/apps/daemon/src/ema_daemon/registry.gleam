//// Named-actor registry (Singularity-style).
////
//// Every actor that needs to be addressable across supervisor
//// boundaries registers under `<kind>:<ulid>` — e.g. `project:01JFY…`
//// — and other contexts look it up via `lookup/1`.
////
//// Rationale: gleam_otp Subjects bind to the specific actor PID; when
//// an actor is restarted, the Subject is stale. The registry mediates
//// lookups so callers can tolerate restarts.

import gleam/dict.{type Dict}
import gleam/erlang/process.{type Subject}

pub type Key =
  String

/// Opaque handle — the registry itself is an actor; callers hold a
/// Subject to its message type. Wave 1 exposes only the message shape;
/// the actor is not wired yet.
pub type Msg {
  Register(key: Key, target: Subject(Dynamic), reply: Subject(Result(Nil, RegistryError)))
  Unregister(key: Key, reply: Subject(Nil))
  Lookup(key: Key, reply: Subject(Result(Subject(Dynamic), RegistryError)))
  List(reply: Subject(List(Key)))
}

pub type RegistryError {
  AlreadyRegistered(Key)
  NotFound(Key)
}

/// Opaque placeholder until we add `gleam/dynamic` typing to messages.
pub type Dynamic

/// In-memory state held by the registry actor.
pub type State {
  State(bindings: Dict(Key, Subject(Dynamic)))
}

/// Fresh empty state.
pub fn empty_state() -> State {
  State(bindings: dict.new())
}
