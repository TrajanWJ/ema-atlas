# 0.0.5 Workspace Entrypoint

Use this repo as the implementation root for EMA `0.0.5`.

## Before coding

Read:

1. `../../doctrine/planning/EMA-0.0.5-LANGUAGE-LOCK.md`
2. `../../doctrine/planning/EMA-0.0.5-PASSOVER-AND-PREP.md`
3. `../../doctrine/planning/lane3-domain-model-and-system-design.md`
4. `../../data-model/EMA-DATA-TREATMENT-AND-SOURCE-OF-TRUTH.md`
5. `architecture/08-vanilla-workspace.md`

## First build assumptions

- backend language direction: Gleam / BEAM
- desktop shell direction: Tauri
- shared surface layer: web-based UI reused by desktop and browser
- Blueprint is the first deep project-thinking vApp
- git-ema is the first source/attachment vApp
- the first milestone is a vanilla workspace, not the full workflow engine

## First product surfaces to support

- shell topbar
- organization interface
- space interface
- project interface
- settings interface
- invites and memberships
- Blueprint vApp
- git-ema attachment/source surface

## First anti-drift rule

Do not let the first UI own truth.

The first codebase should encode the authority split from day one:

- daemon owns truth
- runtime owns execution
- surfaces render and request actions
