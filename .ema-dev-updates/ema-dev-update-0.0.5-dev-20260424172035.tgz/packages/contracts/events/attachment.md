# attachment

Owner: `ema_attachments` (the git-ema backend).

See `docs/architecture/07-git-ema.md` and `types/attachment.md`.

## Kinds

### `attachment.created`
```
payload {
  attachment_id: attachment:<ulid>
  kind:          "file" | "folder" | "git_repo" | "git_path"
               | "drive_file" | "drive_folder"
  source:        "local" | "google_drive" | "github" | "git_url"
  display_name:  string
  mime?:         string
  size_bytes?:   int
  source_ref:    <SourceRef>   // see types/attachment.md
  created_by:    device:<ulid>
}
```

### `attachment.renamed`
```
payload { attachment_id, from, to }
```

### `attachment.deleted`
```
payload { attachment_id, deleted_by: user:<ulid>, reason? }
```

### `attachment.linked`
```
payload {
  attachment_id: attachment:<ulid>
  object_kind:   "project" | "space" | "blueprint_section" | "proposal"
               | "incident" | "lane_item"
  object_id:     string              // typed id of the target object
  by:            user:<ulid>
}
```

Contexts that want to know about attachments on their own objects SHOULD
subscribe to `attachment.linked` and filter on `object_kind`. They MAY
also mirror it into their own family (e.g. `blueprint.attachment.linked`)
for convenience — the mirror is always *after* the canonical event.

### `attachment.unlinked`
```
payload { attachment_id, object_kind, object_id, by }
```
