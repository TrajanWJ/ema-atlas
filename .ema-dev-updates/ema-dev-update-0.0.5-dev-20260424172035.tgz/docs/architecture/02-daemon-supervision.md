# 02 — Daemon supervision

The daemon is a Gleam/BEAM application. It owns all canonical truth and is
the only writer to the canonical SQLite database.

## Top-level tree

```
ema_daemon_sup (one_for_one)
├── bus              (singleton event-bus actor; append-then-fan-out)
├── registry         (Singularity-style named-actor registry)
├── shell_ipc_sup    (localhost WS acceptor + per-connection workers)
└── contexts_sup     (rest_for_one)
    ├── identity_sup
    ├── orgs_sup
    ├── spaces_sup
    ├── projects_sup
    ├── memberships_sup
    ├── invites_sup
    ├── blueprint_sup
    ├── attachments_sup   (git-ema backend — attachments + connectors)
    └── replication_sup
```

### Strategy notes

- `ema_daemon_sup` is `one_for_one`: the bus, registry, and IPC server each
  crash independently.
- `contexts_sup` is `rest_for_one` so that if `identity_sup` dies, every
  downstream context is restarted with fresh state. Identity is upstream of
  everything.
- Each `<context>_sup` is `one_for_one` and owns:
  - a thin `<context>_writer` actor (handles command → event append)
  - zero-or-more per-entity actors started on demand (e.g., one per open
    project) and registered by `<kind>:<ulid>`.

## Registry

The registry maps stable names (`project:<ulid>`, `space:<ulid>`, etc.) to
current `Subject(Message)` values. Any actor restart must re-register under
the same name before accepting traffic. Cross-context code MUST go through
the registry; hardcoded Subjects across supervisor boundaries are banned.

See `packages/contracts/types/ids.md` for key format.

## Event bus

A singleton actor at the top. All writer actors append through the bus so
that:

1. append order is linear per daemon instance;
2. projections and the IPC fan-out subscribe in one place;
3. replication reads from the bus' tail.

See `03-event-catalog-v0.md`.

## IPC

`shell_ipc_sup` runs a localhost WebSocket server that surfaces (Tauri
desktop, browser tab) connect to. The wire protocol is defined in
`packages/contracts/ipc/shell-protocol.md`. Surfaces never write to SQLite
directly.

## Bounded-context folder layout

One folder per context under `apps/daemon/src/`:

```
ema_identity/   ema_orgs/       ema_spaces/
ema_projects/  ema_memberships/ ema_invites/
ema_blueprint/ ema_attachments/ ema_replication/
ema_shell_ipc/
```

Each context's public API is exposed via one module that only the
corresponding supervisor and the IPC server are expected to call.
