# @ema/contracts

Language-neutral contracts shared by daemon and surfaces.

This package is the **single source of truth** for:

- event kinds (`events/`)
- canonical record shapes (`types/`)
- IPC protocol between daemon and surfaces (`ipc/`)

Everything here is documentation-first. Each doc is the authoritative
spec; generated Gleam and TypeScript bindings live alongside when the
generator wave ships. Until then, daemon code and surface code both refer
to these docs by path + anchor.

## Rules

1. No code depends on something that is not in this package.
2. Additive changes to contracts do not require version bumps.
3. Breaking changes ship a new versioned file (`catalog.v1.md`,
   `shell-protocol.v1.md`) and a migration note; the old file is never
   edited.
4. Event kinds used anywhere in the codebase MUST be listed in
   `events/catalog.v0.md` (enforced by `tooling/contract-check.sh`).

## Layout

```
events/
  catalog.v0.md          list of every kind in every family
  <family>.md            per-family definitions, payload shapes
types/
  ids.md                 ULID + typed prefix + registry key conventions
  attachment.md          attachment record schema
  connector.md           connector record schema
ipc/
  shell-protocol.md      daemon↔surface websocket protocol
```
