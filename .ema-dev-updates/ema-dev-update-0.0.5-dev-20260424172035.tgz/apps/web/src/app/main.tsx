import React from "react";
import { createRoot } from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";

import { ShellLayout } from "../shell/shell-layout";
import { BlueprintPage } from "../vapps/blueprint";
import { GitEmaPage } from "../vapps/git-ema";
import { SettingsPage } from "./settings-page";
import { IpcProvider } from "../lib/ipc";

const router = createBrowserRouter([
  {
    path: "/",
    element: <ShellLayout />,
    children: [
      {
        index: true,
        element: <Navigate to="/git-ema" replace />,
      },
      {
        path: "orgs/:orgId/spaces/:spaceId/projects/:projectId",
        element: <BlueprintPage />,
      },
      {
        path: "orgs/:orgId/spaces/:spaceId/projects/:projectId/git-ema",
        element: <GitEmaPage scope="project" />,
      },
      {
        path: "settings",
        element: <SettingsPage />,
      },
      {
        path: "git-ema",
        element: <GitEmaPage scope="user" />,
      },
    ],
  },
]);

const rootEl = document.getElementById("root");
if (!rootEl) throw new Error("#root not found");

createRoot(rootEl).render(
  <React.StrictMode>
    <IpcProvider>
      <RouterProvider router={router} />
    </IpcProvider>
  </React.StrictMode>,
);
